var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a9db9534-488e-4f22-addc-f2b07eec54e1","f564b58c-6f7b-4e43-b712-85913c8adaf9","c56c7e94-2eec-48c7-b729-ae15d86788b5","ee8394f3-2195-4865-9a6e-08209408dd87","ce2a4418-e8af-4d4a-938f-24cbcdc90ff2"],"propsByKey":{"a9db9534-488e-4f22-addc-f2b07eec54e1":{"name":"Pedro","sourceUrl":null,"frameSize":{"x":170,"y":390},"frameCount":1,"looping":true,"frameDelay":12,"version":"LtxTX8Qc0kOoKeMLh_IbQho4ReNeRObY","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":170,"y":390},"rootRelativePath":"assets/a9db9534-488e-4f22-addc-f2b07eec54e1.png"},"f564b58c-6f7b-4e43-b712-85913c8adaf9":{"name":"Ac1","sourceUrl":null,"frameSize":{"x":187,"y":270},"frameCount":1,"looping":true,"frameDelay":12,"version":"VP7L6Wbo46i90aV74M_KeLL6eN6JxikQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":187,"y":270},"rootRelativePath":"assets/f564b58c-6f7b-4e43-b712-85913c8adaf9.png"},"c56c7e94-2eec-48c7-b729-ae15d86788b5":{"name":"Ac2","sourceUrl":null,"frameSize":{"x":187,"y":270},"frameCount":1,"looping":true,"frameDelay":12,"version":"h5n8mozz3TYdxgmyxFx6vy00f4iaL.wz","loadedFromSource":true,"saved":true,"sourceSize":{"x":187,"y":270},"rootRelativePath":"assets/c56c7e94-2eec-48c7-b729-ae15d86788b5.png"},"ee8394f3-2195-4865-9a6e-08209408dd87":{"name":"Ac3","sourceUrl":null,"frameSize":{"x":187,"y":270},"frameCount":1,"looping":true,"frameDelay":12,"version":"TAJxoYQK8cC0QOAiaihmaTvpv_59jAtW","loadedFromSource":true,"saved":true,"sourceSize":{"x":187,"y":270},"rootRelativePath":"assets/ee8394f3-2195-4865-9a6e-08209408dd87.png"},"ce2a4418-e8af-4d4a-938f-24cbcdc90ff2":{"name":"Ac4","sourceUrl":null,"frameSize":{"x":187,"y":270},"frameCount":1,"looping":true,"frameDelay":12,"version":"5I8smEg0qcA2K2PZ4Qp8Mp4ausXlgw0.","loadedFromSource":true,"saved":true,"sourceSize":{"x":187,"y":270},"rootRelativePath":"assets/ce2a4418-e8af-4d4a-938f-24cbcdc90ff2.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


///Pedro levou um salgadinho muito gostoso para a escola,  
///por isso todos os seus amigos queriam comer , ajude pedro a chegar no local seguro, 
///lembrando que você só tem 5 tentativas




var life = 5;
var Ac1, Ac2, Ac3,Ac4;
var boundary1, boundary2;
var Pedro;
var gameState; 
var gameState="jogar";

  boundary1 = createSprite(190,120,420,3);
  boundary2 = createSprite(190,260,420,3);
  
  Pedro = createSprite(20,190,13,13);
  Pedro.shapeColor = "green";
  Pedro.setAnimation("Pedro");
Pedro.scale=0.1;

  Ac1 = createSprite(100,130,10,10);
  Ac1.shapeColor = "red";
  Ac1.setAnimation("Ac1");
  Ac1.scale=0.1;
  
  
  Ac2 = createSprite(246,209,10,10);
  Ac2.shapeColor = "red";
   Ac2.setAnimation("Ac2");
  Ac2.scale=0.1;
  
  Ac3 = createSprite(165,250,10,10);
  Ac3.shapeColor = "red";
   Ac3.setAnimation("Ac3");
  Ac3.scale=0.1;
  
  Ac4 = createSprite(314,190,10,10);
   Ac4.setAnimation("Ac4");
  Ac4.scale=0.1;
  
  Ac4.shapeColor = "red";
  
 
//adicione velocidade para fazer o carro se mover.
Ac1.velocityY = 8;
  Ac2.velocityY = 8;
  Ac3.velocityY = -8;
  Ac4.velocityY = -8;
  
  
function draw() {
   background("white");
   
    textSize(50);
      fill("blue");
  text("Vidas: " + life,200,61);


  strokeWeight(0);
  fill("lightblue");
  rect(0,120,52,140);
  fill("yellow");
  rect(345,120,52,140);
  
// crie a função rebater, para fazer o carro rebater nos limites
Ac1.bounceOff(boundary1);
  Ac1.bounceOff(boundary2);
  Ac2.bounceOff(boundary1);
  Ac2.bounceOff(boundary2);
  Ac3.bounceOff(boundary1);
  Ac3.bounceOff(boundary2);
  Ac4.bounceOff(boundary1);
  Ac4.bounceOff(boundary2);
  
  if(gameState==="jogar"){

//Adicione a condição para fazer Sam se mover para a esquerda e para a direita
 if(keyDown("right")){
    Pedro.x = Pedro.x + 7;
  }
  if(keyDown("left")){
    Pedro.x = Pedro.x - 7;
  }
  
//Adicione a condição para reduzir a vida de Sam quando ele encostar no carro.
  if(
     Pedro.isTouching(Ac1)||
     Pedro.isTouching(Ac2)||
     Pedro.isTouching(Ac3)||
     Pedro.isTouching(Ac4))
  {
     Pedro.x = 20;
     Pedro.y = 190;
     life = life -1;
  }
    if(life===0)
    gameState="fim";
    
  }
if(gameState === "fim"){
  fill("red");
  textSize(20);
  textAlign(CENTER,CENTER);
  text("fim de Jogo", 200,280);
  
  Ac1.velocityY = 0;

Ac2.velocityY = 0;

  Ac3.velocityY = 0;

  Ac4.velocityY = 0;
}
 drawSprites();
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
